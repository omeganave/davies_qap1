/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - name: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

window.products = [
  {
    id: "p1",
    name: "The Wall",
    description: "Pink Floyd's eleventh studio album, released in 1979. Considered one of the greatest concept albums of all time. 2016 pressing.",
    price: 5000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p2",
    name: "Sgt. Pepper's Lonely Hearts Club Band",
    description: "The Beatles' eighth studio album, released in 1967. Regarded as one of the earliest concept albums, and one of The Beatles' greatest albums. 2017 pressing.",
    price: 3500,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p3",
    name: "News of the World",
    description: "Queen's sixth studio album, released in 1977. Regarded as one of Queen's greatest albums. 2020 pressing.",
    price: 3500,
    discontinued: true,
    categories: ["c1"]
  },
  {
    id: "p4",
    name: "Marvin's Marvelous Mechanical Museum",
    description: "Tally Hall's debut studio album, released in 2005. Received generally positive reviews on release. 2022 'Silent Explosive' pressing.",
    price: 4000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p5",
    name: "Random Access Memories",
    description: "Daft Punk's fourth studio album, released in 2013. The final album created by Daft Punk before their 2021 disbandment. 2021 pressing.",
    price: 4500,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p6",
    name: "The Singles Collection",
    description: "A collection of reissues of all of of the original Beatles singles, released in 2019. Also includes a new double A-side of 'Free as a Bird' and 'Real Love'. 2019 pressing.",
    price: 25000,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p7",
    name: "Final Space",
    description: "Includes the songs 'Good Kind of Dangerous' and 'Gallows' from the TV series 'Final Space', released in 2018. 2018 'Mooncake' green pressing.",
    price: 5000,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p8",
    name: "Just a Friend",
    description: "Tally Hall's cover of Biz Markie's 'Just a Friend', also including bonus tracks 'Mucka Blucka' and 'Dream', released in 2020. 2021 clear w/ black splatter pressing.",
    price: 2500,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p9",
    name: "Instant Karma!",
    description: "Includes the songs 'Instant Karma!' by John Lennon and 'Who Has Seen The Wind?' by Yoko Ono, released in 1970. 2020 pressing.",
    price: 1500,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p10",
    name: "The Rumbling",
    description: "Includes the full, instrumental and TV size versions of 'The Rumbling' by SiM, released in 2022. Used as the opening to Season 4 Part 2 of anime series 'Attack on Titan'. 2022 12\" pressing.",
    price: 2500,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p11",
    name: "Twist and Shout",
    description: "The Beatles' first EP, released in 1963. Topped the UK EP chart for twenty-one weeks straight. 1963(?) pressing.",
    price: 500,
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "p12",
    name: "Zoom In",
    description: "Ringo Starr's 2021 EP. Received average reviews upon release. 2021 pressing.",
    price: 2500,
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "p13",
    name: "The ELO EP",
    description: "Electric Light Orchestra's first and last EP, released in 1978. 1978 pressing.",
    price: 500,
    discontinued: true,
    categories: ["c3"]
  },
  {
    id: "p14",
    name: "Prospekt's March",
    description: "Coldplay's seventh EP, released in 2008. Features left-over tracks from the Viva la Vida sessions. 2008 pressing.",
    price: 8000,
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "p15",
    name: "My Iron Lung",
    description: "Radiohead's third EP, released in 1994. Consists of the song of the same name from the album 'The Bends', and several non-album tracks. 1994 pressing.",
    price: 10000,
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "p16",
    name: "45-RPM Adapter",
    description: "Makes 45-RPM records with larger holes playable on all turntables.",
    price: 1000,
    discontinued: false,
    categories: ["c4"]
  },
  {
    id: "p17",
    name: "Record Weight Stabilizer",
    description: "Ensures the stability of a record while playing, keeping needle motion to a minimum. Especially useful for records with slight warps.",
    price: 3000,
    discontinued: false,
    categories: ["c4"]
  },
  {
    id: "p18",
    name: "Outer Sleeves",
    description: "Contains 100 clear plastic outer record sleeves, perfect for 12\"s.",
    price: 3000,
    discontinued: false,
    categories: ["c4"]
  },
  {
    id: "p19",
    name: "Record Cleaning Kit",
    description: "Contains a soft velvet record brush, stylus brush, cleaning solution and storage pouch.",
    price: 4000,
    discontinued: false,
    categories: ["c4"]
  },
  {
    id: "p20",
    name: "AT-LP60X Stereo Turntable",
    description: "An Audio-Technica 2-speed record player. Perfect for new vinyl owners.",
    price: 20000,
    discontinued: false,
    categories: ["c4"]
  },
  {
    id: "p21",
    name: "Mona Bone Jakon",
    description: "Cat Stevens' third studio album, released in 1970. Unknown pressing.",
    price: 3000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p22",
    name: "A New World Record",
    description: "Electric Light Orchestra's sixth studio album, released in 1976. ELO's first top ten album in the UK. 1976 pressing.",
    price: 500,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p23",
    name: "Hold On Tight",
    description: "Electric Light Orchestra's 1981 single from their album 'Time'. 1981 pressing.",
    price: 200,
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "p24",
    name: "Gorillaz",
    description: "Gorillaz' self-titled debut studio album, released in 2001. Sold over seven million copies worldwide. 2015 pressing.",
    price: 4000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p25",
    name: "Kid A",
    description: "Radiohead's fourth studio album, released in 2000. Radiohead released no singles or music videos from the album. 2016 pressing.",
    price: 5000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p26",
    name: "Venus and Mars",
    description: "Wings' fourth studio album, released in 1975. Paul McCartney's first post-Beatles album to be released by Capitol Records. 1975 pressing.",
    price: 1000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p27",
    name: "Undertale Complete OST",
    description: "The complete original soundtrack to Toby Fox's UNDERTALE, released in 2015. Contains five coloured LPs. 2021 pressing.",
    price: 18000,
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "p28",
    name: "King of Fuh",
    description: "1969 single by Brute Force, only 1000 copies pressed by Apple Records. Extremely rare (this is one of the ones that I don't actually own). 1969 Apple pressing.",
    price: 300000,
    discontinued: false,
    categories: ["c2"]
  }
];
