/**
 * QAP1 - FRONT-END & JAVASCRIPT!!
 *
 *
 * Please update the following with your information:
 *
 *      Name:       Evan Davies
 *      
 *      Date:       <SUBMISSION_DATE>
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { products, categories } = window;

// Loading the main program
addEventListener("DOMContentLoaded", main);



// The main program
function main() {
  console.log("This site is meant to be viewed in full screen!")
  // console.log({ products, categories }, "Store Data");
  // Setting up buttons
  var btnCounter = 1
  categories.forEach(element => {
    var catMenu = document.querySelector("#category-menu");
    var div = document.createElement("div");
    div.innerHTML = `<button id = "btn${btnCounter}">${element.description}</button>`;
    btnCounter += 1;
    catMenu.appendChild(div);
  });

  // Setting up the category name (unnecessary now that it's automatically set to the first category anyway)
  catSpace = document.querySelector("#category");
  catSpace.innerHTML = "No category selected"
  listProducts(1);
  // Lists products in a category in the table, and displays the category name
  function listProducts(cat) {
    document.querySelector("#category").innerHTML = `${categories[cat-1].description}`;
    // console.log(`Clicked ${categories[cat-1].description}`);
    var table = document.querySelector("#products");
    table.innerHTML = "";
    products.forEach(element => {
      var tr = document.createElement("tr");
      if (element.categories.includes(`c${cat}`) === true && element.discontinued === false) {
      tr.innerHTML = `<td>${element.name}</td><td>${element.description}</td><td class="price">${toCad(element.price)}</td>`;
      table.appendChild(tr);
      tr.addEventListener("click", function () {
        console.log(element);
        console.log(element.name);
      });
      };
    });
  };

  // Converts prices to CAD
  function toCad(price) {
    return new Intl.NumberFormat("en-CA", {
      style:"currency",
      currency:"CAD"
    }).format(price/100);
  };

  // Button click events
  const lpButton = document.querySelector("#btn1");
  lpButton.addEventListener("click", function () {
    listProducts(1);
  });

  const singleButton = document.querySelector("#btn2");
  singleButton.addEventListener("click", function () {
    listProducts(2);
  });

  const epButton = document.querySelector("#btn3");
  epButton.addEventListener("click", function () {
    listProducts(3);
  });

  const accButton = document.querySelector("#btn4");
  accButton.addEventListener("click", function () {
    listProducts(4);
  });

};

